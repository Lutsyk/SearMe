export const FIREBASE_CONFIG = {
    apiKey: "AIzaSyA44UC2ULrv17w5stlZMfo9DOKYlyvlIF8",
    authDomain: "searme-8dec5.firebaseapp.com",
    databaseURL: "https://searme-8dec5.firebaseio.com",
    projectId: "searme-8dec5",
    storageBucket: "searme-8dec5.appspot.com",
    messagingSenderId: "406945037747"
  };
